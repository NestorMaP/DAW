<?php $__env->startSection('content'); ?>
    <h1>Listado de películas.</h1>
    <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
            <p>Título: <a href="<?php echo e(route('movies.show', $movie->slug)); ?>"><?php echo e($movie->title); ?></a></p>
            <p>Nota: <?php echo e($movie->vote_average); ?>.</p>
            <p>Sinopsis: <?php echo e(Str::limit($movie->overview, 200)); ?> .</p>
        </div>
        <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php echo e($movies->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nesxr\Documents\GitHub\DAW\Git-2º\DWES\Exam_Practice_2\InfoPelisExam\resources\views/movies/index.blade.php ENDPATH**/ ?>