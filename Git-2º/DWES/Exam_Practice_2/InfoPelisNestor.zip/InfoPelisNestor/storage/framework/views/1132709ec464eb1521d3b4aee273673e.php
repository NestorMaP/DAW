<?php $__env->startSection('content'); ?>

    <h1><?php echo e($person->person_name); ?></h1>
    <div class="container">
        <h2>Movies as director</h2>
        <?php if($directedMovies->isEmpty()): ?>
            <p>No ha dirigido ninguna película.</p>
        <?php else: ?>
            <?php $__currentLoopData = $directedMovies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crew): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('movies.show', $crew->movie->id)); ?>"><?php echo e($crew->movie->title); ?>, </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>

    <div class="container">
        <h2>Movies as actor/actress</h2>
        <?php if($actedMovies->isEmpty()): ?>
            <p>No ha actudado en ninguna película</p>
        <?php else: ?>
            <?php $__currentLoopData = $actedMovies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('movies.show', $cast->movie->id)); ?>"><?php echo e($cast->movie->title); ?>, </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nesxr\Documents\GitHub\DAW\Git-2º\DWES\Exam_Practice_2\InfoPelisExam\resources\views/persons/show.blade.php ENDPATH**/ ?>