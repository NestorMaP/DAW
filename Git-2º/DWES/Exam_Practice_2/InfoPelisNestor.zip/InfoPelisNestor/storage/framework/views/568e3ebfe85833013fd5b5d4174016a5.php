<?php $__env->startSection('content'); ?>
    <?php if(!auth()->check() || auth()->user()->rol !== 'admin'): ?>
        <div>
            <h2>No estás autorizado para crear películas. Inicia sesión con una cuenta con privilegios.</h2>
            <p><a href="<?php echo e(route('loginForm')); ?>">Iniciar sesión.</a></p>
            <p><a href="<?php echo e(route('signupForm')); ?>">Regístrate.</a></p>
        </div>
    <?php else: ?>

    <h1>Editar película <?php echo e($movie->title); ?> </h1>

    
    
    <form action="<?php echo e(route('movies.update', $movie->slug)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        
        <div>
            <label for="title">Title: </label>
            <input type="text" name="title" id="title" value="<?php echo e(old('title', $movie->title)); ?>">
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: red;"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <br>

        
        <div>
            <label for="budget">Budget: </label>
            <input type="number" name="budget" id="budget" value="<?php echo e(old('budget', $movie->budget)); ?>">

        </div>
        <br>

        
        <div>
            <label for="homepage">Homepage:  </label>
            <input type="text" name="homepage" id="homepage" value="<?php echo e(old('homepage', $movie->homepage)); ?>">
            <?php $__errorArgs = ['homepage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: red;"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <br>

        
        <div>
            <label for="overview">Overview: </label>
            <input type="text" name="overview" id="overview" value="<?php echo e(old('overview', $movie->overview)); ?>">
            <?php $__errorArgs = ['overview'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: red;"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <br>

        
        <div>
            <label for="popularity">Popularity: </label>
            <input type="number" name="popularity" id="popularity" value="<?php echo e(old('popularity', $movie->popularity)); ?>">

        </div>
        <br>

        
        <div>
            <label for="release_date">Release Date: </label>
            <input type="text" name="release_date" id="release_date" value="<?php echo e(old('release_date', $movie->release_date)); ?>" placeholder="YYYY/mm/dd">
            <?php $__errorArgs = ['release_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: red;"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <br>

        
        <div>
            <label for="revenue">Revenue: </label>
            <input type="number" name="revenue" id="revenue" value="<?php echo e(old('revenue', $movie->revenue)); ?>">

        </div>
        <br>

        
        <div>
            <label for="runtime">Runtime: </label>
            <input type="number" name="runtime" id="runtime" value="<?php echo e(old('runtime', $movie->runtime)); ?>">

        </div>
        <br>

        
        <div>
            <label for="movie_status">Movie Status: </label>
            <input type="text" name="movie_status" id="movie_status" value="<?php echo e(old('movie_status', $movie->movie_status)); ?>">

        </div>
        <br>

        
        <div>
            <label for="tagline">Tagline: </label>
            <input type="text" name="tagline" id="tagline" value="<?php echo e(old('tagline', $movie->tagline)); ?>">

        </div>
        <br>

        
        <div>
            <label for="vote_average">Vote Average: </label>
            <input type="number" name="vote_average" id="vote_average" value="<?php echo e(old('vote_average', $movie->vote_average)); ?>">
            <?php $__errorArgs = ['vote_average'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: red;"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <br>

        
        <div>
            <label for="vote_count">Vote Count: </label>
            <input type="number" name="vote_count" id="vote_count" value="<?php echo e(old('vote_count', $movie->vote_count)); ?>">

        </div>
        <br>

        
        <div>
            <label for="image">Current Picture</label>
            <?php if($movie->image): ?>
                <img src="<?php echo e($movie->image_url); ?>" alt="Imagen de <?php echo e($movie->title); ?>" width="150">
            <?php else: ?>
                <p>There is no picture</p>
            <?php endif; ?>
        </div>

        <div>
            <label for="image">Nueva Imagen</label>
            <input type="file" name="image" id="image">
            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: red;"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit">Enviar</button>

    </form>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nesxr\Documents\GitHub\DAW\Git-2º\DWES\Exam_Practice_2\InfoPelisExam\resources\views/movies/edit.blade.php ENDPATH**/ ?>