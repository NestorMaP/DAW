
<form action="<?php echo e(route('signup')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <h1>Registro de usuarios</h1><br>

    <label for="name">Nombre:</label><br>
    <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>"><br>

    <label for="surname">Apelllido:</label><br>
    <input type="text" name="surname" id="surname" value="<?php echo e(old('surname')); ?>"><br>

    <label for="nickname">Nick:</label><br>
    <input type="text" name="nickname" id="nickname" value="<?php echo e(old('nickname')); ?>"><br>

    <label for="email">Correo: </label><br>
    <input type="text" name="email" id="email" value="<?php echo e(old('email')); ?>"><br>

    <label for="password">Contraseña: </label><br>
    <input type="password" name="password" id="password"><br>

    <label for="password_confirmation">Repite la contraseña: </label><br>
    <input type="password" name="password_confirmation" id="password_confirmation"><br>
    <br>

    <input type="submit" value="Enviar">
</form>

<?php if($errors->any()): ?>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>
<?php /**PATH C:\Users\nesxr\Documents\GitHub\DAW\Git-2º\DWES\Exam_Practice_2\InfoPelisExam\resources\views/auth/signup.blade.php ENDPATH**/ ?>