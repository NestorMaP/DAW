<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>

    </head>
    <body>
        
        Página de Néstor, bienvenido a InfoPelis
    </body>
</html>
<?php /**PATH C:\Users\nesxr\Documents\GitHub\DAW\Git-2º\DWES\Exam_Practice_2\InfoPelisExam\resources\views/welcome.blade.php ENDPATH**/ ?>