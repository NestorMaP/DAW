<?php $__env->startSection('content'); ?>

<h2><?php echo e($personCast->person_name); ?></h2>
<div class="container">
    

    <h1><?php echo e($personCast->name); ?></h1>
<h2>Películas:</h2>
<ul>
    <?php $__currentLoopData = $personCast->movieCast; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a href="<?php echo e(route('movies.show', $cast->movie->id)); ?>">
                <?php echo e($cast->movie->title); ?>

            </a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</ul>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nesxr\Documents\GitHub\DAW\Git-2º\DWES\Exam_Practice_2\InfoPelisExam\resources\views/actors/show.blade.php ENDPATH**/ ?>