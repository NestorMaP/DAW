<?php $__env->startSection('content'); ?>

    <div class="container">
        <h1><?php echo e($movie->title); ?></h1>
        <p><strong>ID:</strong> <?php echo e($movie->id); ?></p>
        
            <p>
                <strong>Director:</strong>
                <a href="<?php echo e(route('actors.show',$movie->director->person->id)); ?>">
                    <?php echo e($movie->director->person->person_name); ?>

                </a>
            </p>
        <p><strong>Budget:</strong> <?php echo e($movie->budget); ?> USD</p>
        <p><strong>Homepage:</strong> <?php echo e($movie->homepage); ?></p>
        <p><strong>Overview:</strong> <?php echo e($movie->overview); ?>''</p>
        <p><strong>Popularity:</strong> <?php echo e($movie->popularity); ?></p>
        <p><strong>Release Date:</strong> <?php echo e($movie->release_date); ?></p>
        <p><strong>Revenue:</strong> <?php echo e($movie->revenue); ?></p>
        <p><strong>Runtime:</strong> <?php echo e($movie->runtime); ?></p>
        <p><strong>Movie Status:</strong> <?php echo e($movie->movie_status); ?></p>
        <p><strong>Tagline:</strong> <?php echo e($movie->tagline); ?></p>
        <p><strong>Vote Average:</strong> <?php echo e($movie->vote_average); ?></p>
        <p><strong>Vote Count:</strong> <?php echo e($movie->vote_count); ?></p>

        
        <p><strong>Actores: </strong>
            <?php $__currentLoopData = $movie->movieCast->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($cast->person->person_name); ?>,
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('movies.characters', $movie->id)); ?>">Resto del Casting</a> 
        </p>

        
        <?php if($movie->image): ?>
            <img src="<?php echo e(asset($moviesImgPath . '/' . $movie->image)); ?>" alt="Image of <?php echo e($movie->title); ?>" style="width:100px;">
        <?php else: ?>
            <img src="<?php echo e(asset('storage/movies_img/no_image.png')); ?>" alt="No disponible" style="width:100px;">
        <?php endif; ?>
        <br><br>

        <a href="<?php echo e(route('movies.edit', $movie->slug)); ?>">Editar película</a>
    </div>
        <br>
        
        <form action="<?php echo e(route('movies.destroy', $movie->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <input type="submit" style="color:red" value="Eliminar">
        </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nesxr\Documents\GitHub\DAW\Git-2º\DWES\Exam_Practice_2\InfoPelisExam\resources\views/movies/show.blade.php ENDPATH**/ ?>