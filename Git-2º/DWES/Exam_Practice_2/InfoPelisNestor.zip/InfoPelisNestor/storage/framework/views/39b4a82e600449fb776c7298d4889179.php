
<header>
    <a href="<?php echo e(route('index')); ?>">
        <img src="<?php echo e(asset('img/infomovies.png')); ?>" alt="InfoPelis Logo" style="height:50px;">
    </a>
    <nav>
        
        
        <a href="<?php echo e(route('movies.create')); ?>">
            <img src="<?php echo e(asset('img/addFilm.png')); ?>" alt="Add Film" style="height:40px;">
        </a>

        
        <a href="<?php echo e(route('movies.index')); ?>">
            <img src="<?php echo e(asset('img/movies.png')); ?>" alt="Movies Logo" style="height:40px;">
        </a>

        
        <a href="<?php echo e(route('actors.index')); ?>">
            <img src="<?php echo e(asset('img/people.png')); ?>" alt="Persons Logo" style="height:40px;">
        </a>

        
        <a href="<?php echo e(route('directors.index')); ?>">
            <img src="<?php echo e(asset('img/directors.png')); ?>" alt="Directors Logo" style="height:40px;">
        </a>

    </nav>
</header>
<?php /**PATH C:\Users\nesxr\Documents\GitHub\DAW\Git-2º\DWES\Exam_Practice_2\InfoPelisNestor\resources\views/partials/header.blade.php ENDPATH**/ ?>