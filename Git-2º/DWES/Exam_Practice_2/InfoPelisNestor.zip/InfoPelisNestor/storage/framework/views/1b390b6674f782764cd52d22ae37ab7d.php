
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Characters</title>
    <link rel="stylesheet" href="<?php echo e(asset('./css/style.css')); ?>">
</head>
<body>
    <h1>Película</h1>
    <div class="break">
        <?php $__currentLoopData = $characters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $character): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="character">
                <p>Personaje: <?php echo e($character['character_name']); ?></p>
                <p>Actor: <?php echo e($character['person_name']); ?></p>
                <p>Sexo: <?php echo e($character['gender']); ?></p>
            </div>
            <?php if(($loop->index + 1) % 4 == 0): ?>
                <div class="break"></div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</body>
</html>
<?php /**PATH C:\Users\nesxr\Documents\GitHub\DAW\Git-2º\DWES\Exam_Practice_2\InfoPelisExam\resources\views/characters.blade.php ENDPATH**/ ?>