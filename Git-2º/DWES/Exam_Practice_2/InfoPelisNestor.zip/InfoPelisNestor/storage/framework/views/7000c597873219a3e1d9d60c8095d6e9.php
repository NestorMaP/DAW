<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1><?php echo e($movie->title); ?></h1>

        
            <?php $__currentLoopData = $movie->movieCast; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $character): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <p><strong>Personaje: </strong><?php echo e($character->character_name); ?></p>
                    <p><strong>Actor: </strong><a href="<?php echo e(route('actors.show', $character->person->id)); ?>"><?php echo e($character->person->person_name); ?></a></p>
                    <p><strong>Género: </strong><?php echo e($character->gender->gender); ?></p>
                <div>
                <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nesxr\Documents\GitHub\DAW\Git-2º\DWES\Exam_Practice_2\InfoPelisExam\resources\views/movies/characters.blade.php ENDPATH**/ ?>