;

<?php $__env->startSection('content'); ?>
    <?php if(!auth()->check() || auth()->user()->rol !== 'admin'): ?>
        <div>
            <h2>No estás autorizado para crear películas. Inicia sesión con una cuenta con privilegios.</h2>
            <p><a href="<?php echo e(route('loginForm')); ?>">Iniciar sesión.</a></p>
            <p><a href="<?php echo e(route('signupForm')); ?>">Regístrate.</a></p>
        </div>
    <?php else: ?>
    <h1>Añadir película</h1>
    
    
    <form action="<?php echo e(route('movies.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        
        <div>
            <label for="title">Title: </label>
            <input type="text" name="title" id="title">
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: red;"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <br>

        
        <div>
            <label for="director">Director: </label>
            <input list="directors" name="director" id="director">
            <datalist id="directors">
                <?php $__currentLoopData = $directors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $director): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($director); ?>"></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </datalist>
        </div>
        <br>


        
        <div>
            <label for="budget">Budget: </label>
            <input type="number" name="budget" id="budget">

        </div>
        <br>

        
        <div>
            <label for="homepage">Homepage:  </label>
            <input type="text" name="homepage" id="homepage">
            <?php $__errorArgs = ['homepage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: red;"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <br>

        
        <div>
            <label for="overview">Overview: </label>
            <input type="text" name="overview" id="overview">
            <?php $__errorArgs = ['overview'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: red;"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <br>

        
        <div>
            <label for="popularity">Popularity: </label>
            <input type="number" name="popularity" id="popularity">

        </div>
        <br>

        
        <div>
            <label for="release_date">Release Date: </label>
            <input type="text" name="release_date" id="release_date" value="<?php echo e(old('release_date')); ?>" placeholder="YYYY/mm/dd">
            <?php $__errorArgs = ['release_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: red;"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <br>

        
        <div>
            <label for="revenue">Revenue: </label>
            <input type="number" name="revenue" id="revenue">

        </div>
        <br>

        
        <div>
            <label for="runtime">Runtime: </label>
            <input type="number" name="runtime" id="runtime">

        </div>
        <br>

        
        <div>
            <label for="movie_status">Movie Status: </label>
            <input type="text" name="movie_status" id="movie_status">

        </div>
        <br>

        
        <div>
            <label for="tagline">Tagline: </label>
            <input type="text" name="tagline" id="tagline">

        </div>
        <br>

        
        <div>
            <label for="vote_average">Vote Average: </label>
            <input type="number" name="vote_average" id="vote_average">
            <?php $__errorArgs = ['vote_average'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: red;"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <br>

        
        <div>
            <label for="vote_count">Vote Count: </label>
            <input type="number" name="vote_count" id="vote_count">

        </div>
        <br>

        
        <div>
            <label for="image">Imagen</label>
            <input type="file" name="image" id="image">

        </div>

        <button type="submit">Enviar</button>

    </form>

    <?php endif; ?>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nesxr\Documents\GitHub\DAW\Git-2º\DWES\Exam_Practice_2\InfoPelisExam\resources\views/movies/create.blade.php ENDPATH**/ ?>