
<footer>
    <p>Néstor Mateo Prats &#x00A9; <?php echo e(date('Y')); ?></p>
</footer>
<?php /**PATH C:\Users\nesxr\Documents\GitHub\DAW\Git-2º\DWES\Exam_Practice_2\InfoPelisExam\resources\views/partials/footer.blade.php ENDPATH**/ ?>