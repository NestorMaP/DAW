
<h1>Hola <?php echo e(Auth::user()->nickname); ?></h1>

<p>Esta es tu información:</p>
<p><strong>Nombre: </strong><?php echo e(Auth::user()->name); ?>

<p><strong>Apellido: </strong><?php echo e(Auth::user()->surname); ?>

<p><strong>Nick: </strong><?php echo e(Auth::user()->nickname); ?>

<p><strong>Correo: </strong><?php echo e(Auth::user()->email); ?>

<p><strong>Rol: </strong><?php echo e(Auth::user()->rol); ?>


<?php if(Auth::viaRemember()): ?>
    <p><strong>Has iniciado sesión con la opción "Recuérdame".</strong></p>
<?php endif; ?>

<br><br>

<a href="<?php echo e(route('logout')); ?>">Cerrar sesión.</a>
<br><br>
<a href="<?php echo e(route('index')); ?>">Volver al inicio.</a>
<?php /**PATH C:\Users\nesxr\Documents\GitHub\DAW\Git-2º\DWES\Exam_Practice_2\InfoPelisExam\resources\views/auth/user.blade.php ENDPATH**/ ?>