<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1><?php echo e($movie->title); ?></h1>

        
        <p><strong>Actores: </strong>
            <?php $__currentLoopData = $movie->movieCast; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ul>
                    <li><?php echo e($cast->person->person_name); ?></li>
                </ul>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nesxr\Documents\GitHub\DAW\Git-2º\DWES\Exam_Practice_2\InfoPelisExam\resources\views/movie_cast/show.blade.php ENDPATH**/ ?>