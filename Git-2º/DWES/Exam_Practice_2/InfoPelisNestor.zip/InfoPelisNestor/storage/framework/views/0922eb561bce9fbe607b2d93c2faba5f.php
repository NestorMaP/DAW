<?php $__env->startSection('content'); ?>
<div class="container">
    
    <h1>Listado de actores:</h1>
        <?php $__currentLoopData = $actors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <p><strong>Nombre: </strong>
                    <a href="<?php echo e(route('persons.show', $actor->id)); ?>"><?php echo e($actor->person_name); ?></a>
                </p>
                <p><strong>Películas: </strong>
                    <ul>
                        <?php $__currentLoopData = $actor->movieCast->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movies): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($movies->movie->title); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </p>
            </div>
            <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div>
        <?php echo e($actors->links()); ?>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nesxr\Documents\GitHub\DAW\Git-2º\DWES\Exam_Practice_2\InfoPelisExam\resources\views/actors/index.blade.php ENDPATH**/ ?>