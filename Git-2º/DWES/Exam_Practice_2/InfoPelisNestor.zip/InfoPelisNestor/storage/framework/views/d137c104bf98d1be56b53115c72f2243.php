
<form action="<?php echo e(route('login')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <h1>Login</h1>

    <label for="email">Correo: </label><br>
    <input type="text" name="email" id="email" value="<?php echo e(old('email')); ?>"><br>

    <label for="password">Contraseña: </label><br>
    <input type="password" name="password" id="password"><br>

    <label>
        <input type="checkbox" name="remember">Recuérdame
    </label>
    <br><br>

    <input type="submit" value="Enviar">
</form>

<?php if($errors->any()): ?>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>
<?php /**PATH C:\Users\nesxr\Documents\GitHub\DAW\Git-2º\DWES\Exam_Practice_2\InfoPelisExam\resources\views/auth/login.blade.php ENDPATH**/ ?>