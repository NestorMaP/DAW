<?php $__env->startSection('content'); ?>
    <h1>Bienvenido a InfoPelis</h1>
    <p><a href="<?php echo e(route('loginForm')); ?>">
        <?php if(auth()->check()): ?>
            Mi perfil
        <?php else: ?>
            Iniciar sesión
        <?php endif; ?>
    </a></p>
    <p><a href="<?php echo e(route('signupForm')); ?>">Regístrate</a></p>
    <img src="<?php echo e(asset('img/welcome.png')); ?>" alt="Movies" style="max-width:50%; height:auto;">
    <p>Pasa a disfrutar del universo cinéfilo de primera mano</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nesxr\Documents\GitHub\DAW\Git-2º\DWES\Exam_Practice_2\InfoPelisExam\resources\views/index.blade.php ENDPATH**/ ?>