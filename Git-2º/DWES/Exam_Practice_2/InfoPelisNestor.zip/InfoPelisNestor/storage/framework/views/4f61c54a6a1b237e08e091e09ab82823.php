;

<?php $__env->startSection('content'); ?>
    <h1>Listado de películas</h1>
    <p>Próximamente aquí encontraras todas las películas disponibles
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nesxr\Documents\GitHub\DAW\Git-2º\DWES\Exam_Practice_2\InfoPelisExam\resources\views/movies/list.blade.php ENDPATH**/ ?>