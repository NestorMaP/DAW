<?php $__env->startSection('content'); ?>
    <h1>Error 404</h1>
    <h2>Página no encontrada</h2>
    <a href="<?php echo e(route('index')); ?>">Volver</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\nesxr\Documents\GitHub\DAW\Git-2º\DWES\Exam_Practice_2\InfoPelisExam\resources\views/errors/404.blade.php ENDPATH**/ ?>