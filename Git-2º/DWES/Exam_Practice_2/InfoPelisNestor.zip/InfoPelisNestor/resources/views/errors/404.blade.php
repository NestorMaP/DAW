@extends('layout')

@section('content')
    <h1>Error 404</h1>
    <h2>Página no encontrada</h2>
    <a href="{{ route('index') }}">Volver</a>
@endsection
