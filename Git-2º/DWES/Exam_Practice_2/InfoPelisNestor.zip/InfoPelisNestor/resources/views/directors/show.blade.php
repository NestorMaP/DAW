{{-- Práctica 3 --}}
@extends('layout')

@section('content')
    <h1>Aquí se muestra la ficha de un director en específico según Néstor Mateo</h1>
@endsection
