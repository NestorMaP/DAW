<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>

    </head>
    <body>
        {{-- Práctica 2--}}
        Página de Néstor, bienvenido a InfoPelis
    </body>
</html>
