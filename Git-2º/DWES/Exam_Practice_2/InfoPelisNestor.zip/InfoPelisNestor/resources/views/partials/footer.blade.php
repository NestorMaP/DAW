{{-- Práctica 2 --}}
<footer>
    <p>Néstor Mateo Prats &#x00A9; {{ date('Y') }}</p>
</footer>
